import { db } from "./firebase-config.js";
import {
  collection, query, where, limit, getDocs, doc, updateDoc, increment,
} from "https://www.gstatic.com/firebasejs/10.13.1/firebase-firestore.js";
import {
  initTheme, wireChrome, escapeHtml, formatDate, estimateReadingTime,
  plainTextExcerpt, sanitizeArticleHtml, articleHref, categoryHref, getSlugParam,
} from "./utils.js";

initTheme();
document.getElementById("year").textContent = new Date().getFullYear();

const root = document.getElementById("article-root");

function setSeo(article, canonicalUrl) {
  const title = article.seoTitle || `${article.title} — Northfield`;
  const desc = article.seoDescription || article.description || plainTextExcerpt(article.content, 160);
  document.title = title;
  document.getElementById("meta-title").textContent = title;
  document.getElementById("meta-description").setAttribute("content", desc);
  document.getElementById("meta-canonical").setAttribute("href", canonicalUrl);
  document.getElementById("og-title").setAttribute("content", title);
  document.getElementById("og-description").setAttribute("content", desc);
  document.getElementById("og-image").setAttribute("content", article.thumbnailUrl || "");
  document.getElementById("og-url").setAttribute("content", canonicalUrl);
  document.getElementById("tw-title").setAttribute("content", title);
  document.getElementById("tw-description").setAttribute("content", desc);
  document.getElementById("tw-image").setAttribute("content", article.thumbnailUrl || "");

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: article.title,
    description: desc,
    image: article.thumbnailUrl ? [article.thumbnailUrl] : [],
    author: { "@type": "Person", name: article.author || "Northfield" },
    datePublished: article.publishedAt?.toDate ? article.publishedAt.toDate().toISOString() : undefined,
    dateModified: article.updatedAt?.toDate ? article.updatedAt.toDate().toISOString() : undefined,
    mainEntityOfPage: canonicalUrl,
  };
  document.getElementById("jsonld").textContent = JSON.stringify(jsonLd);
}

function relatedCardTemplate(a) {
  return `
    <article class="card">
      <a href="${articleHref(a.slug)}" class="card-thumb"><img src="${a.thumbnailUrl}" alt="${escapeHtml(a.title)}" loading="lazy" /></a>
      <div class="card-cat">${escapeHtml(a.category || "")}</div>
      <h3 class="card-title"><a href="${articleHref(a.slug)}">${escapeHtml(a.title)}</a></h3>
      <div class="card-foot"><span>${formatDate(a.publishedAt)}</span><a href="${articleHref(a.slug)}" class="card-readmore">Read more →</a></div>
    </article>`;
}

async function loadRelated(article) {
  try {
    const q = query(
      collection(db, "articles"),
      where("status", "==", "published"),
      where("category", "==", article.category),
      limit(6)
    );
    const snap = await getDocs(q);
    let related = snap.docs.map((d) => d.data()).filter((a) => a.slug !== article.slug);
    if (!related.length && article.tags?.length) {
      const tq = query(collection(db, "articles"), where("status", "==", "published"), where("tags", "array-contains-any", article.tags.slice(0, 10)), limit(6));
      const tsnap = await getDocs(tq);
      related = tsnap.docs.map((d) => d.data()).filter((a) => a.slug !== article.slug);
    }
    related = related.slice(0, 3);
    const wrap = document.getElementById("related-grid");
    if (!wrap) return;
    wrap.innerHTML = related.length
      ? related.map(relatedCardTemplate).join("")
      : `<p style="font-family:var(--font-ui); color:var(--muted)">No related articles yet.</p>`;
  } catch (err) {
    console.error(err);
  }
}

function bumpViewOnce(articleId, slug) {
  const key = `viewed:${slug}`;
  if (sessionStorage.getItem(key)) return;
  sessionStorage.setItem(key, "1");
  updateDoc(doc(db, "articles", articleId), { views: increment(1) }).catch(() => {});
}

function renderArticle(id, article) {
  const canonicalUrl = `${window.location.origin}${articleHref(article.slug)}`;
  setSeo(article, canonicalUrl);

  const readingTime = estimateReadingTime(article.content);
  const safeContent = sanitizeArticleHtml(article.content);

  root.innerHTML = `
    <div class="container">
      <div class="breadcrumb">
        <a href="index.html">Home</a> /
        <a href="${categoryHref((article.category || "").toLowerCase())}">${escapeHtml(article.category || "")}</a> /
        <span>${escapeHtml(article.title)}</span>
      </div>
    </div>
    <div class="article-head">
      <div class="article-cat"><a href="${categoryHref((article.category || "").toLowerCase())}">${escapeHtml(article.category || "")}</a></div>
      <h1 class="article-title">${escapeHtml(article.title)}</h1>
      <div class="article-meta">
        <span>By ${escapeHtml(article.author || "")}</span>
        <span class="divider"></span>
        <span>${formatDate(article.publishedAt)}</span>
        <span class="divider"></span>
        <span>${readingTime}</span>
      </div>
    </div>
    <div class="article-main-thumb">
      <div class="frame"><img src="${article.thumbnailUrl}" alt="${escapeHtml(article.title)}" /></div>
    </div>
    <div class="article-body">${safeContent}</div>
    <div class="container" style="max-width:${getComputedStyle(document.documentElement).getPropertyValue("--content-width")}">
      <div class="article-tags" id="article-tags"></div>
      <div class="share-row">
        <span>Share this article</span>
        <button class="btn btn-outline btn-sm" id="share-btn">Copy link</button>
      </div>
    </div>
    <div class="related-section">
      <h2 class="section-title" style="margin-bottom:24px">Related articles</h2>
      <div class="article-grid" id="related-grid">
        <div class="card skeleton-card"><div class="card-thumb"></div></div>
        <div class="card skeleton-card"><div class="card-thumb"></div></div>
        <div class="card skeleton-card"><div class="card-thumb"></div></div>
      </div>
    </div>
  `;

  document.getElementById("article-tags").innerHTML = (article.tags || [])
    .map((t) => `<span class="pill">${escapeHtml(t)}</span>`).join("");

  document.getElementById("share-btn").addEventListener("click", async () => {
    if (navigator.share) {
      try { await navigator.share({ title: article.title, url: canonicalUrl }); return; } catch { /* fall through */ }
    }
    await navigator.clipboard.writeText(canonicalUrl);
    const btn = document.getElementById("share-btn");
    const original = btn.textContent;
    btn.textContent = "Link copied!";
    setTimeout(() => { btn.textContent = original; }, 1800);
  });

  bumpViewOnce(id, article.slug);
  loadRelated(article);
}

async function load() {
  const slug = getSlugParam("slug");
  if (!slug) {
    root.innerHTML = `<div class="container"><div class="empty-state"><h3>Article not found</h3><p>No article slug was provided.</p></div></div>`;
    return;
  }
  try {
    const snap = await getDocs(query(collection(db, "articles"), where("slug", "==", slug), where("status", "==", "published"), limit(1)));
    if (snap.empty) {
      root.innerHTML = `<div class="container"><div class="empty-state"><h3>Article not found</h3><p>This article may have been unpublished or removed.</p></div></div>`;
      return;
    }
    const d = snap.docs[0];
    renderArticle(d.id, d.data());
  } catch (err) {
    console.error(err);
    root.innerHTML = `<div class="container"><div class="empty-state"><h3>Couldn't load this article</h3><p>${escapeHtml(err.message)}</p></div></div>`;
  }
}

async function handleSearch(term, resultsEl) {
  if (!term) { resultsEl.innerHTML = ""; return; }
  const snap = await getDocs(query(collection(db, "articles"), where("status", "==", "published")));
  const t = term.toLowerCase();
  const matches = snap.docs.map((d) => d.data())
    .filter((a) => a.title?.toLowerCase().includes(t) || a.category?.toLowerCase().includes(t) || (a.tags || []).some((tag) => tag.toLowerCase().includes(t)))
    .slice(0, 8);
  resultsEl.innerHTML = matches.length
    ? matches.map((a) => `<a class="search-result-item" href="${articleHref(a.slug)}"><img src="${a.thumbnailUrl}" alt="" /><div><div class="t">${escapeHtml(a.title)}</div><div class="c">${escapeHtml(a.category || "")}</div></div></a>`).join("")
    : `<div class="search-empty">No articles found</div>`;
}

wireChrome({ onSearch: handleSearch });
load();
