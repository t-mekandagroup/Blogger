import { db, storage } from "./firebase-config.js";
import {
  collection, doc, addDoc, updateDoc, deleteDoc, getDocs, query, where, serverTimestamp,
} from "https://www.gstatic.com/firebasejs/10.13.1/firebase-firestore.js";
import {
  ref, uploadBytesResumable, getDownloadURL, deleteObject,
} from "https://www.gstatic.com/firebasejs/10.13.1/firebase-storage.js";
import {
  slugify, escapeHtml, toast, sanitizeArticleHtml, estimateReadingTime, formatDate,
} from "./utils.js";

const rte = document.getElementById("rte");
const thumbDrop = document.getElementById("thumb-drop");
const thumbInput = document.getElementById("thumb-input");
const thumbPreview = document.getElementById("thumb-preview");
const thumbProgress = document.getElementById("thumb-upload-progress");
const contentImageInput = document.getElementById("content-image-input");
const contentProgress = document.getElementById("content-upload-progress");
const tagRow = document.getElementById("tag-row");
const tagInput = document.getElementById("f-tag-input");

let currentEditId = null;
let currentThumbnailUrl = "";
let currentThumbnailPath = "";
let tags = [];
let savedRange = null;

// --------------------------------------------------------------------------
// Toolbar
// --------------------------------------------------------------------------
document.getElementById("rte-toolbar").addEventListener("click", (e) => {
  const btn = e.target.closest(".tb-btn");
  if (!btn || !btn.dataset.cmd) return;
  rte.focus();
  document.execCommand(btn.dataset.cmd, false, btn.dataset.val || null);
});

document.getElementById("tb-code").addEventListener("click", () => {
  rte.focus();
  const sel = window.getSelection();
  const text = sel.toString() || "// your code here";
  document.execCommand("insertHTML", false, `<pre><code>${escapeHtml(text)}</code></pre><p><br></p>`);
});

document.getElementById("tb-link").addEventListener("click", () => {
  const url = window.prompt("Link URL (https://…)");
  if (!url) return;
  rte.focus();
  document.execCommand("createLink", false, url);
});

document.getElementById("tb-image").addEventListener("click", () => {
  savedRange = getCurrentRange();
  contentImageInput.click();
});

function getCurrentRange() {
  const sel = window.getSelection();
  if (sel.rangeCount === 0) return null;
  return sel.getRangeAt(0);
}

function restoreRange() {
  if (!savedRange) return;
  const sel = window.getSelection();
  sel.removeAllRanges();
  sel.addRange(savedRange);
}

contentImageInput.addEventListener("change", async () => {
  const file = contentImageInput.files[0];
  contentImageInput.value = "";
  if (!file) return;
  try {
    const url = await uploadImage(file, "content", contentProgress);
    const caption = window.prompt("Optional image caption (leave blank to skip):", "") || "";
    rte.focus();
    restoreRange();
    const figureHtml = `<figure contenteditable="false"><img src="${url}" alt="${escapeHtml(caption)}" />${caption ? `<figcaption>${escapeHtml(caption)}</figcaption>` : ""}</figure><p><br></p>`;
    document.execCommand("insertHTML", false, figureHtml);
    toast("Image inserted");
  } catch (err) {
    toast(err.message || "Image upload failed", "error");
  }
});

function uploadImage(file, kind, progressEl) {
  return new Promise((resolve, reject) => {
    const path = `articles/${kind}/${Date.now()}-${file.name.replace(/\s+/g, "-")}`;
    const storageRef = ref(storage, path);
    const task = uploadBytesResumable(storageRef, file);
    progressEl.style.display = "block";
    const bar = progressEl.querySelector(".bar");
    task.on("state_changed",
      (snap) => { bar.style.width = `${(snap.bytesTransferred / snap.totalBytes) * 100}%`; },
      (err) => { progressEl.style.display = "none"; reject(err); },
      async () => {
        progressEl.style.display = "none";
        bar.style.width = "0%";
        const url = await getDownloadURL(task.snapshot.ref);
        resolve(url, path);
      }
    );
  });
}

// --------------------------------------------------------------------------
// Thumbnail
// --------------------------------------------------------------------------
thumbDrop.addEventListener("click", () => thumbInput.click());
thumbInput.addEventListener("change", async () => {
  const file = thumbInput.files[0];
  thumbInput.value = "";
  if (!file) return;
  const localUrl = URL.createObjectURL(file);
  thumbPreview.src = localUrl;
  thumbPreview.style.display = "block";
  try {
    const path = `thumbnails/${Date.now()}-${file.name.replace(/\s+/g, "-")}`;
    const storageRef = ref(storage, path);
    const task = uploadBytesResumable(storageRef, file);
    thumbProgress.style.display = "block";
    const bar = thumbProgress.querySelector(".bar");
    task.on("state_changed",
      (snap) => { bar.style.width = `${(snap.bytesTransferred / snap.totalBytes) * 100}%`; },
      (err) => { thumbProgress.style.display = "none"; toast(err.message || "Thumbnail upload failed", "error"); },
      async () => {
        thumbProgress.style.display = "none";
        bar.style.width = "0%";
        currentThumbnailUrl = await getDownloadURL(task.snapshot.ref);
        currentThumbnailPath = path;
        toast("Thumbnail uploaded");
      }
    );
  } catch (err) {
    toast(err.message || "Thumbnail upload failed", "error");
  }
});

// --------------------------------------------------------------------------
// Tags
// --------------------------------------------------------------------------
function renderTags() {
  tagRow.querySelectorAll(".tag-chip").forEach((el) => el.remove());
  tags.forEach((t, i) => {
    const chip = document.createElement("span");
    chip.className = "tag-chip";
    chip.innerHTML = `${escapeHtml(t)} <button type="button" data-i="${i}">×</button>`;
    tagRow.insertBefore(chip, tagInput);
  });
}
tagRow.addEventListener("click", (e) => {
  if (e.target.tagName === "BUTTON") {
    tags.splice(Number(e.target.dataset.i), 1);
    renderTags();
  }
});
tagInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter" || e.key === ",") {
    e.preventDefault();
    const val = tagInput.value.trim().replace(/,$/, "");
    if (val && !tags.includes(val)) { tags.push(val); renderTags(); }
    tagInput.value = "";
  }
});

// --------------------------------------------------------------------------
// Slug auto-fill
// --------------------------------------------------------------------------
const titleInput = document.getElementById("f-title");
const slugInput = document.getElementById("f-slug");
let slugManuallyEdited = false;
slugInput.addEventListener("input", () => { slugManuallyEdited = true; });
titleInput.addEventListener("input", () => {
  if (!slugManuallyEdited) slugInput.value = slugify(titleInput.value);
});

// --------------------------------------------------------------------------
// Category select
// --------------------------------------------------------------------------
export function populateCategorySelect(categories) {
  const select = document.getElementById("f-category");
  const currentVal = select.value;
  select.innerHTML = categories.map((c) => `<option value="${escapeHtml(c.name)}">${escapeHtml(c.name)}</option>`).join("");
  if (currentVal) select.value = currentVal;
}

// --------------------------------------------------------------------------
// Reset / load
// --------------------------------------------------------------------------
export function resetEditor() {
  currentEditId = null;
  currentThumbnailUrl = "";
  currentThumbnailPath = "";
  tags = [];
  slugManuallyEdited = false;
  document.getElementById("editor-heading").textContent = "Create article";
  titleInput.value = "";
  slugInput.value = "";
  document.getElementById("f-desc").value = "";
  document.getElementById("f-author").value = "";
  document.getElementById("f-seo-title").value = "";
  document.getElementById("f-seo-desc").value = "";
  document.getElementById("f-seo-keywords").value = "";
  rte.innerHTML = "";
  thumbPreview.style.display = "none";
  thumbPreview.src = "";
  renderTags();
}

export function loadArticleIntoEditor(id, article) {
  currentEditId = id;
  currentThumbnailUrl = article.thumbnailUrl || "";
  currentThumbnailPath = article.thumbnailPath || "";
  tags = [...(article.tags || [])];
  slugManuallyEdited = true;
  document.getElementById("editor-heading").textContent = `Edit — ${article.title}`;
  titleInput.value = article.title || "";
  slugInput.value = article.slug || "";
  document.getElementById("f-desc").value = article.description || "";
  document.getElementById("f-category").value = article.category || "";
  document.getElementById("f-author").value = article.author || "";
  document.getElementById("f-seo-title").value = article.seoTitle || "";
  document.getElementById("f-seo-desc").value = article.seoDescription || "";
  document.getElementById("f-seo-keywords").value = (article.seoKeywords || []).join(", ");
  rte.innerHTML = article.content || "";
  if (currentThumbnailUrl) { thumbPreview.src = currentThumbnailUrl; thumbPreview.style.display = "block"; }
  else { thumbPreview.style.display = "none"; }
  renderTags();
}

export function getCurrentEditId() { return currentEditId; }

// --------------------------------------------------------------------------
// Validation + save
// --------------------------------------------------------------------------
function collectFields() {
  return {
    title: titleInput.value.trim(),
    slug: slugify(slugInput.value.trim() || titleInput.value.trim()),
    description: document.getElementById("f-desc").value.trim(),
    content: rte.innerHTML.trim(),
    category: document.getElementById("f-category").value,
    tags,
    author: document.getElementById("f-author").value.trim() || "Northfield",
    thumbnailUrl: currentThumbnailUrl,
    thumbnailPath: currentThumbnailPath,
    seoTitle: document.getElementById("f-seo-title").value.trim(),
    seoDescription: document.getElementById("f-seo-desc").value.trim(),
    seoKeywords: document.getElementById("f-seo-keywords").value.split(",").map((s) => s.trim()).filter(Boolean),
  };
}

async function slugIsTaken(slug, excludeId) {
  const snap = await getDocs(query(collection(db, "articles"), where("slug", "==", slug)));
  return snap.docs.some((d) => d.id !== excludeId);
}

export async function saveArticle(status, { onSaved } = {}) {
  const fields = collectFields();
  if (!fields.title) return toast("Please add a title before saving", "error");
  if (!fields.slug) return toast("Please add a URL slug", "error");
  if (!fields.thumbnailUrl) return toast("Please upload a 16:9 thumbnail", "error");
  if (!fields.content || fields.content === "<br>") return toast("Please write some article content", "error");
  if (status === "published" && !fields.category) return toast("Please choose a category before publishing", "error");

  if (await slugIsTaken(fields.slug, currentEditId)) {
    return toast("That URL slug is already used by another article", "error");
  }

  fields.content = sanitizeArticleHtml(fields.content);

  try {
    if (currentEditId) {
      const updates = { ...fields, status, updatedAt: serverTimestamp() };
      if (status === "published") updates.publishedAt = updates.publishedAt || serverTimestamp();
      await updateDoc(doc(db, "articles", currentEditId), updates);
      toast(status === "published" ? "Article published" : "Draft saved");
    } else {
      const payload = {
        ...fields,
        status,
        views: 0,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        publishedAt: status === "published" ? serverTimestamp() : null,
      };
      const docRef = await addDoc(collection(db, "articles"), payload);
      currentEditId = docRef.id;
      toast(status === "published" ? "Article published" : "Draft saved");
    }
    onSaved?.(status);
  } catch (err) {
    console.error(err);
    toast(err.message || "Couldn't save the article", "error");
  }
}

export async function publishExisting(id) {
  await updateDoc(doc(db, "articles", id), { status: "published", publishedAt: serverTimestamp(), updatedAt: serverTimestamp() });
}
export async function unpublishExisting(id) {
  await updateDoc(doc(db, "articles", id), { status: "draft", updatedAt: serverTimestamp() });
}
export async function deleteArticleAndAssets(article, id) {
  try {
    if (article.thumbnailPath) await deleteObject(ref(storage, article.thumbnailPath)).catch(() => {});
  } catch { /* best effort */ }
  await deleteDoc(doc(db, "articles", id));
}

// --------------------------------------------------------------------------
// Preview
// --------------------------------------------------------------------------
export function openPreview() {
  const fields = collectFields();
  const safeContent = sanitizeArticleHtml(fields.content);
  const modal = document.getElementById("preview-modal");
  document.getElementById("preview-content").innerHTML = `
    <div class="article-head" style="padding-top:36px">
      <div class="article-cat">${escapeHtml(fields.category || "Uncategorized")}</div>
      <h1 class="article-title">${escapeHtml(fields.title || "Untitled article")}</h1>
      <div class="article-meta">
        <span>By ${escapeHtml(fields.author)}</span>
        <span class="divider"></span>
        <span>${formatDate(new Date())}</span>
        <span class="divider"></span>
        <span>${estimateReadingTime(fields.content)}</span>
      </div>
    </div>
    ${fields.thumbnailUrl ? `<div class="article-main-thumb"><div class="frame"><img src="${fields.thumbnailUrl}" /></div></div>` : ""}
    <div class="article-body">${safeContent}</div>
    <div class="container" style="max-width:700px">
      <div class="article-tags">${fields.tags.map((t) => `<span class="pill">${escapeHtml(t)}</span>`).join("")}</div>
    </div>
  `;
  modal.classList.add("open");
}
document.getElementById("close-preview").addEventListener("click", () => {
  document.getElementById("preview-modal").classList.remove("open");
});
