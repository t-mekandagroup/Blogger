import { db } from "./firebase-config.js";
import {
  collection, query, where, orderBy, limit, startAfter, getDocs, getCountFromServer,
} from "https://www.gstatic.com/firebasejs/10.13.1/firebase-firestore.js";
import {
  initTheme, wireChrome, escapeHtml, formatDate, plainTextExcerpt,
  articleHref, categoryHref, DEFAULT_CATEGORIES,
} from "./utils.js";

initTheme();
document.getElementById("year").textContent = new Date().getFullYear();

const PAGE_SIZE = 6;
let lastVisible = null;
let reachedEnd = false;

const heroContent = document.getElementById("hero-content");
const latestGrid = document.getElementById("latest-grid");
const popularGrid = document.getElementById("popular-grid");
const categoryGrid = document.getElementById("category-grid");
const footerCategories = document.getElementById("footer-categories");
const loadMoreBtn = document.getElementById("load-more-btn");

function cardTemplate(article) {
  const desc = article.description || plainTextExcerpt(article.content, 130);
  return `
    <article class="card">
      <a href="${articleHref(article.slug)}" class="card-thumb">
        <img src="${article.thumbnailUrl}" alt="${escapeHtml(article.title)}" loading="lazy" />
      </a>
      <div class="card-cat"><a href="${categoryHref(article.category?.toLowerCase() || "")}">${escapeHtml(article.category || "")}</a></div>
      <h3 class="card-title"><a href="${articleHref(article.slug)}">${escapeHtml(article.title)}</a></h3>
      <p class="card-desc">${escapeHtml(desc)}</p>
      <div class="card-foot">
        <span>${escapeHtml(article.author || "")} · ${formatDate(article.publishedAt)}</span>
        <a href="${articleHref(article.slug)}" class="card-readmore">Read more →</a>
      </div>
    </article>`;
}

function heroTemplate(article) {
  const desc = article.description || plainTextExcerpt(article.content, 200);
  return `
    <div class="hero-grid">
      <div>
        <div class="hero-eyebrow">${escapeHtml(article.category || "Featured")}</div>
        <h1 class="hero-title">${escapeHtml(article.title)}</h1>
        <p class="hero-desc">${escapeHtml(desc)}</p>
        <a href="${articleHref(article.slug)}" class="btn btn-primary">Read more →</a>
        <div class="hero-meta">By ${escapeHtml(article.author || "")} · ${formatDate(article.publishedAt)}</div>
      </div>
      <div class="hero-thumb"><img src="${article.thumbnailUrl}" alt="${escapeHtml(article.title)}" /></div>
    </div>`;
}

async function loadHeroAndLatest() {
  try {
    const q = query(
      collection(db, "articles"),
      where("status", "==", "published"),
      orderBy("publishedAt", "desc"),
      limit(PAGE_SIZE + 1)
    );
    const snap = await getDocs(q);
    const docs = snap.docs;
    if (!docs.length) {
      heroContent.innerHTML = `<div class="empty-state"><h3>No articles yet</h3><p>Check back soon — new writing is on the way.</p></div>`;
      latestGrid.innerHTML = "";
      return;
    }
    const featured = { id: docs[0].id, ...docs[0].data() };
    heroContent.innerHTML = heroTemplate(featured);

    const rest = docs.slice(1, PAGE_SIZE + 1);
    lastVisible = rest.length ? rest[rest.length - 1] : docs[0];
    reachedEnd = docs.length <= PAGE_SIZE + 1 && rest.length < PAGE_SIZE;

    latestGrid.innerHTML = rest.length
      ? rest.map((d) => cardTemplate(d.data())).join("")
      : `<div class="empty-state"><h3>More is coming soon</h3><p>This is the only article published so far.</p></div>`;

    loadMoreBtn.style.display = reachedEnd || rest.length < PAGE_SIZE ? "none" : "inline-flex";
  } catch (err) {
    console.error(err);
    heroContent.innerHTML = `<div class="empty-state"><h3>Couldn't load articles</h3><p>${escapeHtml(err.message)}</p></div>`;
  }
}

loadMoreBtn.addEventListener("click", async () => {
  if (!lastVisible || reachedEnd) return;
  loadMoreBtn.disabled = true;
  loadMoreBtn.textContent = "Loading…";
  try {
    const q = query(
      collection(db, "articles"),
      where("status", "==", "published"),
      orderBy("publishedAt", "desc"),
      startAfter(lastVisible),
      limit(PAGE_SIZE)
    );
    const snap = await getDocs(q);
    if (snap.empty) { reachedEnd = true; loadMoreBtn.style.display = "none"; return; }
    latestGrid.insertAdjacentHTML("beforeend", snap.docs.map((d) => cardTemplate(d.data())).join(""));
    lastVisible = snap.docs[snap.docs.length - 1];
    if (snap.docs.length < PAGE_SIZE) { reachedEnd = true; loadMoreBtn.style.display = "none"; }
  } catch (err) {
    console.error(err);
  } finally {
    loadMoreBtn.disabled = false;
    loadMoreBtn.textContent = "Load more articles";
  }
});

async function loadPopular() {
  try {
    const q = query(
      collection(db, "articles"),
      where("status", "==", "published"),
      orderBy("views", "desc"),
      limit(4)
    );
    const snap = await getDocs(q);
    popularGrid.innerHTML = snap.empty
      ? `<div class="empty-state"><h3>No views yet</h3><p>Popular articles will appear here once readers start visiting.</p></div>`
      : snap.docs.map((d) => cardTemplate(d.data())).join("");
  } catch (err) {
    console.error(err);
    popularGrid.innerHTML = "";
  }
}

async function loadCategories() {
  try {
    const snap = await getDocs(query(collection(db, "categories"), orderBy("name")));
    let cats = snap.docs.map((d) => d.data());
    if (!cats.length) cats = DEFAULT_CATEGORIES.map((name) => ({ name, slug: name.toLowerCase() }));

    const withCounts = await Promise.all(cats.map(async (c) => {
      try {
        const cq = query(collection(db, "articles"), where("status", "==", "published"), where("category", "==", c.name));
        const countSnap = await getCountFromServer(cq);
        return { ...c, count: countSnap.data().count };
      } catch { return { ...c, count: 0 }; }
    }));

    categoryGrid.innerHTML = withCounts.map((c) => `
      <a class="category-card" href="${categoryHref(c.slug)}">
        <div class="name">${escapeHtml(c.name)}</div>
        <div class="count">${c.count} article${c.count === 1 ? "" : "s"}</div>
      </a>`).join("");

    footerCategories.innerHTML = `<h4>Categories</h4>` + withCounts.slice(0, 5).map((c) =>
      `<a href="${categoryHref(c.slug)}">${escapeHtml(c.name)}</a>`).join("");
  } catch (err) {
    console.error(err);
  }
}

async function handleSearch(term, resultsEl) {
  if (!term) { resultsEl.innerHTML = ""; return; }
  resultsEl.innerHTML = `<div class="search-empty">Searching…</div>`;
  try {
    const snap = await getDocs(query(collection(db, "articles"), where("status", "==", "published"), limit(200)));
    const t = term.toLowerCase();
    const matches = snap.docs
      .map((d) => d.data())
      .filter((a) =>
        a.title?.toLowerCase().includes(t) ||
        a.category?.toLowerCase().includes(t) ||
        (a.tags || []).some((tag) => tag.toLowerCase().includes(t))
      )
      .slice(0, 8);

    resultsEl.innerHTML = matches.length
      ? matches.map((a) => `
          <a class="search-result-item" href="${articleHref(a.slug)}">
            <img src="${a.thumbnailUrl}" alt="" />
            <div><div class="t">${escapeHtml(a.title)}</div><div class="c">${escapeHtml(a.category || "")}</div></div>
          </a>`).join("")
      : `<div class="search-empty">No articles found</div>`;
  } catch (err) {
    resultsEl.innerHTML = `<div class="search-empty">No articles found</div>`;
  }
}

wireChrome({ onSearch: handleSearch });
loadHeroAndLatest();
loadPopular();
loadCategories();
