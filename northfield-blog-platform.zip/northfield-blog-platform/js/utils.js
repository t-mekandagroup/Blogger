// ==========================================================================
// SHARED UTILITIES
// ==========================================================================

export const DEFAULT_CATEGORIES = [
  "Technology", "AI", "Programming", "Education",
  "Blogging", "Internet", "Tips & Tricks", "News", "Other",
];

export function slugify(text) {
  return text
    .toString()
    .trim()
    .toLowerCase()
    .replace(/[^\w\s-]/g, "")
    .replace(/[\s_]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
}

export function escapeHtml(str = "") {
  return str.replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));
}

export function formatDate(ts) {
  if (!ts) return "";
  const d = ts.toDate ? ts.toDate() : new Date(ts);
  return d.toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" });
}

export function estimateReadingTime(html = "") {
  const text = html.replace(/<[^>]*>/g, " ");
  const words = text.trim().split(/\s+/).filter(Boolean).length;
  const minutes = Math.max(1, Math.round(words / 200));
  return `${minutes} min read`;
}

export function plainTextExcerpt(html = "", len = 160) {
  const text = html.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
  return text.length > len ? text.slice(0, len).trim() + "…" : text;
}

// --------------------------------------------------------------------------
// HTML sanitizer for rendering owner-authored article content to visitors.
// Whitelists a fixed set of tags/attributes; strips everything else,
// including inline event handlers and javascript: URLs.
// --------------------------------------------------------------------------
const ALLOWED_TAGS = new Set([
  "P", "H1", "H2", "H3", "STRONG", "B", "EM", "I", "U", "S", "STRIKE",
  "UL", "OL", "LI", "A", "IMG", "FIGURE", "FIGCAPTION", "BLOCKQUOTE",
  "PRE", "CODE", "HR", "BR", "DIV", "SPAN",
]);
const ALLOWED_ATTRS = {
  A: ["href", "target", "rel"],
  IMG: ["src", "alt", "title"],
  DIV: ["style"],
  SPAN: ["style"],
  P: ["style"],
};
const ALLOWED_STYLE_PROPS = new Set(["text-align"]);

function cleanNode(node) {
  const kids = Array.from(node.childNodes);
  for (const child of kids) {
    if (child.nodeType === Node.TEXT_NODE) continue;
    if (child.nodeType !== Node.ELEMENT_NODE) { child.remove(); continue; }
    if (!ALLOWED_TAGS.has(child.tagName)) {
      // Unwrap disallowed tags (keep their text/children) rather than
      // dropping content the owner wrote.
      while (child.firstChild) node.insertBefore(child.firstChild, child);
      node.removeChild(child);
      continue;
    }
    const allowedAttrs = ALLOWED_ATTRS[child.tagName] || [];
    for (const attr of Array.from(child.attributes)) {
      const name = attr.name.toLowerCase();
      if (!allowedAttrs.includes(name)) { child.removeAttribute(attr.name); continue; }
      if (name === "href" || name === "src") {
        const val = attr.value.trim();
        if (/^javascript:/i.test(val)) { child.removeAttribute(attr.name); continue; }
      }
      if (name === "style") {
        const kept = attr.value.split(";")
          .map((s) => s.trim()).filter(Boolean)
          .filter((decl) => ALLOWED_STYLE_PROPS.has(decl.split(":")[0]?.trim()));
        if (kept.length) child.setAttribute("style", kept.join("; "));
        else child.removeAttribute("style");
      }
    }
    if (child.tagName === "A") {
      child.setAttribute("target", "_blank");
      child.setAttribute("rel", "noopener noreferrer nofollow");
    }
    if (child.tagName === "IMG") child.setAttribute("loading", "lazy");
    cleanNode(child);
  }
}

export function sanitizeArticleHtml(html) {
  const doc = new DOMParser().parseFromString(`<div id="root">${html || ""}</div>`, "text/html");
  const root = doc.getElementById("root");
  cleanNode(root);
  return root.innerHTML;
}

// --------------------------------------------------------------------------
// Toasts
// --------------------------------------------------------------------------
function toastStack() {
  let stack = document.querySelector(".toast-stack");
  if (!stack) {
    stack = document.createElement("div");
    stack.className = "toast-stack";
    document.body.appendChild(stack);
  }
  return stack;
}

export function toast(message, type = "success", duration = 3200) {
  const stack = toastStack();
  const el = document.createElement("div");
  el.className = `toast ${type}`;
  el.textContent = message;
  stack.appendChild(el);
  setTimeout(() => el.remove(), duration);
}

// --------------------------------------------------------------------------
// Confirm dialog (replaces window.confirm with the app's own styling)
// --------------------------------------------------------------------------
export function confirmDialog({ title, message, confirmLabel = "Delete", danger = true }) {
  return new Promise((resolve) => {
    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop open";
    backdrop.innerHTML = `
      <div class="modal">
        <h3>${escapeHtml(title)}</h3>
        <p>${escapeHtml(message)}</p>
        <div class="modal-actions">
          <button class="btn btn-ghost" data-act="cancel">Cancel</button>
          <button class="btn ${danger ? "btn-danger" : "btn-primary"}" data-act="confirm">${escapeHtml(confirmLabel)}</button>
        </div>
      </div>`;
    document.body.appendChild(backdrop);
    backdrop.addEventListener("click", (e) => {
      if (e.target === backdrop || e.target.dataset.act === "cancel") { backdrop.remove(); resolve(false); }
      if (e.target.dataset.act === "confirm") { backdrop.remove(); resolve(true); }
    });
  });
}

// --------------------------------------------------------------------------
// Theme (dark / light) — persisted in localStorage
// --------------------------------------------------------------------------
export function initTheme() {
  const saved = localStorage.getItem("theme") ||
    (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
  document.documentElement.setAttribute("data-theme", saved);
}

export function toggleTheme() {
  const cur = document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark";
  document.documentElement.setAttribute("data-theme", cur);
  localStorage.setItem("theme", cur);
}

// --------------------------------------------------------------------------
// Shared navbar / footer wiring (search overlay, mobile drawer, theme button)
// Call after injecting the header/footer markup into the page.
// --------------------------------------------------------------------------
export function wireChrome({ onSearch } = {}) {
  const themeBtn = document.getElementById("theme-toggle");
  if (themeBtn) themeBtn.addEventListener("click", toggleTheme);

  const hamburger = document.getElementById("hamburger");
  const drawer = document.getElementById("mobile-drawer");
  const drawerBackdrop = document.getElementById("drawer-backdrop");
  const closeDrawer = () => { drawer?.classList.remove("open"); drawerBackdrop?.classList.remove("open"); };
  hamburger?.addEventListener("click", () => { drawer?.classList.add("open"); drawerBackdrop?.classList.add("open"); });
  drawerBackdrop?.addEventListener("click", closeDrawer);
  drawer?.querySelectorAll("a").forEach((a) => a.addEventListener("click", closeDrawer));

  const searchBtn = document.getElementById("search-toggle");
  const searchPanel = document.getElementById("search-panel");
  const searchInput = document.getElementById("search-input");
  const searchResults = document.getElementById("search-results");
  const closeSearch = () => { searchPanel?.classList.remove("open"); if (searchInput) searchInput.value = ""; if (searchResults) searchResults.innerHTML = ""; };
  searchBtn?.addEventListener("click", () => { searchPanel?.classList.add("open"); searchInput?.focus(); });
  searchPanel?.addEventListener("click", (e) => { if (e.target === searchPanel) closeSearch(); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeSearch(); });

  if (onSearch && searchInput) {
    let debounceTimer;
    searchInput.addEventListener("input", () => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => onSearch(searchInput.value.trim(), searchResults), 180);
    });
  }
}

export function articleHref(slug) {
  return `article.html?slug=${encodeURIComponent(slug)}`;
}
export function categoryHref(slug) {
  return `category.html?slug=${encodeURIComponent(slug)}`;
}

export function getSlugParam(name = "slug") {
  const url = new URL(window.location.href);
  if (url.searchParams.get(name)) return url.searchParams.get(name);
  // support pretty URLs like /article/my-slug or /category/my-slug when
  // deployed with the provided Netlify _redirects rules.
  const parts = window.location.pathname.split("/").filter(Boolean);
  return parts.length ? decodeURIComponent(parts[parts.length - 1]) : null;
}
