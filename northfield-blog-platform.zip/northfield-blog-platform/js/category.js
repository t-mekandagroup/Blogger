import { db } from "./firebase-config.js";
import { collection, query, where, orderBy, getDocs } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-firestore.js";
import { initTheme, wireChrome, escapeHtml, formatDate, plainTextExcerpt, articleHref, categoryHref, getSlugParam } from "./utils.js";

initTheme();
document.getElementById("year").textContent = new Date().getFullYear();

const grid = document.getElementById("category-grid");
const heading = document.getElementById("category-heading");
const crumb = document.getElementById("crumb-cat");

function cardTemplate(article) {
  const desc = article.description || plainTextExcerpt(article.content, 130);
  return `
    <article class="card">
      <a href="${articleHref(article.slug)}" class="card-thumb">
        <img src="${article.thumbnailUrl}" alt="${escapeHtml(article.title)}" loading="lazy" />
      </a>
      <div class="card-cat">${escapeHtml(article.category || "")}</div>
      <h3 class="card-title"><a href="${articleHref(article.slug)}">${escapeHtml(article.title)}</a></h3>
      <p class="card-desc">${escapeHtml(desc)}</p>
      <div class="card-foot">
        <span>${escapeHtml(article.author || "")} · ${formatDate(article.publishedAt)}</span>
        <a href="${articleHref(article.slug)}" class="card-readmore">Read more →</a>
      </div>
    </article>`;
}

async function load() {
  const slug = getSlugParam("slug");
  if (!slug) {
    grid.innerHTML = `<div class="empty-state"><h3>Category not found</h3></div>`;
    return;
  }
  // Categories are stored by display name; slug is the lowercase form.
  try {
    const catSnap = await getDocs(query(collection(db, "categories"), where("slug", "==", slug)));
    const catName = catSnap.empty ? slug.replace(/-/g, " ") : catSnap.docs[0].data().name;
    heading.textContent = catName;
    crumb.textContent = catName;
    document.getElementById("page-title").textContent = `${catName} — Northfield`;
    document.title = `${catName} — Northfield`;

    const q = query(
      collection(db, "articles"),
      where("status", "==", "published"),
      where("category", "==", catName),
      orderBy("publishedAt", "desc")
    );
    const snap = await getDocs(q);
    grid.innerHTML = snap.empty
      ? `<div class="empty-state"><h3>No articles found</h3><p>Nothing has been published in ${escapeHtml(catName)} yet.</p></div>`
      : snap.docs.map((d) => cardTemplate(d.data())).join("");
  } catch (err) {
    console.error(err);
    grid.innerHTML = `<div class="empty-state"><h3>Couldn't load this category</h3><p>${escapeHtml(err.message)}</p></div>`;
  }
}

async function handleSearch(term, resultsEl) {
  if (!term) { resultsEl.innerHTML = ""; return; }
  const snap = await getDocs(query(collection(db, "articles"), where("status", "==", "published")));
  const t = term.toLowerCase();
  const matches = snap.docs.map((d) => d.data())
    .filter((a) => a.title?.toLowerCase().includes(t) || a.category?.toLowerCase().includes(t) || (a.tags || []).some((tag) => tag.toLowerCase().includes(t)))
    .slice(0, 8);
  resultsEl.innerHTML = matches.length
    ? matches.map((a) => `<a class="search-result-item" href="${articleHref(a.slug)}"><img src="${a.thumbnailUrl}" alt="" /><div><div class="t">${escapeHtml(a.title)}</div><div class="c">${escapeHtml(a.category || "")}</div></div></a>`).join("")
    : `<div class="search-empty">No articles found</div>`;
}

wireChrome({ onSearch: handleSearch });
load();
