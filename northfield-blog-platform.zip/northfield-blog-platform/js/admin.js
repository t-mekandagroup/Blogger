import { auth, db } from "./firebase-config.js";
import {
  onAuthStateChanged, signInWithEmailAndPassword, signOut, updatePassword,
} from "https://www.gstatic.com/firebasejs/10.13.1/firebase-auth.js";
import {
  collection, getDocs, query, orderBy, addDoc, deleteDoc, doc, serverTimestamp, getCountFromServer, where,
} from "https://www.gstatic.com/firebasejs/10.13.1/firebase-firestore.js";
import {
  initTheme, escapeHtml, formatDate, toast, confirmDialog, slugify, DEFAULT_CATEGORIES,
} from "./utils.js";
import {
  populateCategorySelect, resetEditor, loadArticleIntoEditor, getCurrentEditId,
  saveArticle, publishExisting, unpublishExisting, deleteArticleAndAssets, openPreview,
} from "./editor.js";

initTheme();

const loginScreen = document.getElementById("login-screen");
const adminShell = document.getElementById("admin-shell");
let allArticlesCache = [];
let categoriesCache = [];

// ==========================================================================
// AUTH
// ==========================================================================
document.getElementById("login-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const email = document.getElementById("login-email").value.trim();
  const password = document.getElementById("login-password").value;
  const errorBox = document.getElementById("login-error");
  const btn = document.getElementById("login-btn");
  errorBox.style.display = "none";
  btn.disabled = true;
  btn.textContent = "Logging in…";
  try {
    await signInWithEmailAndPassword(auth, email, password);
  } catch (err) {
    errorBox.textContent = friendlyAuthError(err);
    errorBox.style.display = "block";
  } finally {
    btn.disabled = false;
    btn.textContent = "Log in";
  }
});

function friendlyAuthError(err) {
  const map = {
    "auth/invalid-email": "That email address doesn't look right.",
    "auth/user-not-found": "No account found with that email.",
    "auth/wrong-password": "Incorrect password. Please try again.",
    "auth/invalid-credential": "Incorrect email or password.",
    "auth/too-many-requests": "Too many attempts. Please wait a moment and try again.",
  };
  return map[err.code] || "Couldn't log in. Please try again.";
}

document.getElementById("logout-btn").addEventListener("click", () => signOut(auth));

onAuthStateChanged(auth, (user) => {
  if (user) {
    loginScreen.style.display = "none";
    adminShell.style.display = "grid";
    document.getElementById("settings-email").textContent = user.email;
    bootAdmin();
  } else {
    loginScreen.style.display = "flex";
    adminShell.style.display = "none";
  }
});

// ==========================================================================
// PANEL ROUTING
// ==========================================================================
function showPanel(name) {
  document.querySelectorAll(".admin-panel").forEach((p) => p.classList.remove("active"));
  document.getElementById(`panel-${name}`).classList.add("active");
  document.querySelectorAll(".admin-nav-item").forEach((n) => n.classList.remove("active"));
}

document.querySelectorAll(".admin-nav-item[data-panel]").forEach((item) => {
  item.addEventListener("click", () => {
    const panel = item.dataset.panel;
    showPanel(panel);
    item.classList.add("active");
    document.getElementById("admin-sidebar").classList.remove("open");
    document.getElementById("sidebar-backdrop").classList.remove("open");
    if (panel === "create" && item.id === "nav-create") {
      resetEditor();
      populateCategorySelect(categoriesCache.length ? categoriesCache : DEFAULT_CATEGORIES.map((n) => ({ name: n })));
    }
    if (panel === "all") renderAllArticlesTable(item.dataset.filter || "");
    if (panel === "dashboard") loadDashboard();
    if (panel === "categories") renderCategories();
  });
});

document.getElementById("sidebar-toggle").addEventListener("click", () => {
  document.getElementById("admin-sidebar").classList.add("open");
  document.getElementById("sidebar-backdrop").classList.add("open");
});
document.getElementById("sidebar-backdrop").addEventListener("click", () => {
  document.getElementById("admin-sidebar").classList.remove("open");
  document.getElementById("sidebar-backdrop").classList.remove("open");
});

document.getElementById("btn-new-article").addEventListener("click", () => {
  resetEditor();
  populateCategorySelect(categoriesCache.length ? categoriesCache : DEFAULT_CATEGORIES.map((n) => ({ name: n })));
  showPanel("create");
});

// ==========================================================================
// BOOT — load categories + articles once authenticated
// ==========================================================================
async function bootAdmin() {
  await loadCategories();
  await loadAllArticles();
  loadDashboard();
}

async function loadCategories() {
  try {
    const snap = await getDocs(query(collection(db, "categories"), orderBy("name")));
    categoriesCache = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    if (!categoriesCache.length) {
      // Seed defaults so the owner has something to pick from immediately.
      for (const name of DEFAULT_CATEGORIES) {
        await addDoc(collection(db, "categories"), { name, slug: slugify(name), createdAt: serverTimestamp() });
      }
      const reseed = await getDocs(query(collection(db, "categories"), orderBy("name")));
      categoriesCache = reseed.docs.map((d) => ({ id: d.id, ...d.data() }));
    }
    populateCategorySelect(categoriesCache);
  } catch (err) {
    console.error(err);
  }
}

async function loadAllArticles() {
  try {
    const snap = await getDocs(query(collection(db, "articles"), orderBy("updatedAt", "desc")));
    allArticlesCache = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
  } catch (err) {
    console.error(err);
    toast("Couldn't load articles", "error");
  }
}

// ==========================================================================
// DASHBOARD
// ==========================================================================
function loadDashboard() {
  const total = allArticlesCache.length;
  const published = allArticlesCache.filter((a) => a.status === "published").length;
  const drafts = allArticlesCache.filter((a) => a.status === "draft").length;
  const views = allArticlesCache.reduce((sum, a) => sum + (a.views || 0), 0);
  document.getElementById("stat-total").textContent = total;
  document.getElementById("stat-published").textContent = published;
  document.getElementById("stat-drafts").textContent = drafts;
  document.getElementById("stat-views").textContent = views;

  const recent = [...allArticlesCache].sort((a, b) => (b.updatedAt?.seconds || 0) - (a.updatedAt?.seconds || 0)).slice(0, 5);
  document.getElementById("dashboard-recent").innerHTML = recent.length
    ? recent.map((a) => `
        <tr>
          <td><img class="thumb-mini" src="${a.thumbnailUrl || ""}" alt="" /></td>
          <td>${escapeHtml(a.title)}</td>
          <td><span class="status-chip ${a.status}">${a.status}</span></td>
          <td>${a.views || 0}</td>
          <td>${formatDate(a.updatedAt)}</td>
        </tr>`).join("")
    : `<tr><td colspan="5" style="color:var(--muted); padding:20px 12px">No articles yet — create your first one.</td></tr>`;
}

// ==========================================================================
// ALL ARTICLES TABLE
// ==========================================================================
const allSearchInput = document.getElementById("all-search");
const allStatusFilter = document.getElementById("all-status-filter");
const allSortSelect = document.getElementById("all-sort");

function renderAllArticlesTable(presetFilter) {
  document.getElementById("all-title").textContent =
    presetFilter === "published" ? "Published articles" : presetFilter === "draft" ? "Draft articles" : "All Articles";
  allStatusFilter.value = presetFilter || "";
  paintTable();
}

function paintTable() {
  const term = allSearchInput.value.trim().toLowerCase();
  const status = allStatusFilter.value;
  const [sortField, sortDir] = allSortSelect.value.split("-");

  let rows = allArticlesCache.filter((a) => {
    if (status && a.status !== status) return false;
    if (!term) return true;
    return a.title?.toLowerCase().includes(term) ||
      a.category?.toLowerCase().includes(term) ||
      (a.tags || []).some((t) => t.toLowerCase().includes(term));
  });

  rows.sort((a, b) => {
    let av, bv;
    if (sortField === "views") { av = a.views || 0; bv = b.views || 0; }
    else if (sortField === "title") { av = a.title || ""; bv = b.title || ""; return sortDir === "asc" ? av.localeCompare(bv) : bv.localeCompare(av); }
    else { av = a[sortField]?.seconds || 0; bv = b[sortField]?.seconds || 0; }
    return sortDir === "asc" ? av - bv : bv - av;
  });

  const tbody = document.getElementById("all-articles-body");
  document.getElementById("all-empty").style.display = rows.length ? "none" : "block";
  tbody.innerHTML = rows.map((a) => `
    <tr>
      <td><img class="thumb-mini" src="${a.thumbnailUrl || ""}" alt="" /></td>
      <td>${escapeHtml(a.title)}</td>
      <td>${escapeHtml(a.category || "—")}</td>
      <td><span class="status-chip ${a.status}">${a.status}</span></td>
      <td>${a.views || 0}</td>
      <td>${formatDate(a.updatedAt)}</td>
      <td>
        <div class="row-actions">
          <button class="btn btn-ghost btn-sm" data-act="edit" data-id="${a.id}">Edit</button>
          ${a.status === "published"
            ? `<button class="btn btn-ghost btn-sm" data-act="unpublish" data-id="${a.id}">Unpublish</button>`
            : `<button class="btn btn-ghost btn-sm" data-act="publish" data-id="${a.id}">Publish</button>`}
          <button class="btn btn-danger btn-sm" data-act="delete" data-id="${a.id}">Delete</button>
        </div>
      </td>
    </tr>`).join("");
}

allSearchInput.addEventListener("input", paintTable);
allStatusFilter.addEventListener("change", paintTable);
allSortSelect.addEventListener("change", paintTable);

document.getElementById("all-articles-body").addEventListener("click", async (e) => {
  const btn = e.target.closest("button[data-act]");
  if (!btn) return;
  const id = btn.dataset.id;
  const article = allArticlesCache.find((a) => a.id === id);
  if (!article) return;

  if (btn.dataset.act === "edit") {
    loadArticleIntoEditor(id, article);
    populateCategorySelect(categoriesCache.length ? categoriesCache : DEFAULT_CATEGORIES.map((n) => ({ name: n })));
    showPanel("create");
  }
  if (btn.dataset.act === "publish") {
    await publishExisting(id);
    toast("Article published");
    await loadAllArticles(); paintTable(); loadDashboard();
  }
  if (btn.dataset.act === "unpublish") {
    await unpublishExisting(id);
    toast("Article unpublished");
    await loadAllArticles(); paintTable(); loadDashboard();
  }
  if (btn.dataset.act === "delete") {
    const ok = await confirmDialog({ title: "Delete this article?", message: `"${article.title}" will be permanently deleted. This cannot be undone.` });
    if (!ok) return;
    await deleteArticleAndAssets(article, id);
    toast("Article deleted");
    await loadAllArticles(); paintTable(); loadDashboard();
  }
});

// ==========================================================================
// EDITOR ACTIONS (save draft / publish / preview)
// ==========================================================================
async function afterSave() {
  await loadAllArticles();
  showPanel("all");
  document.querySelector('.admin-nav-item[data-panel="all"]').classList.add("active");
  renderAllArticlesTable("");
  loadDashboard();
}

document.getElementById("btn-save-draft").addEventListener("click", () => saveArticle("draft", { onSaved: afterSave }));
document.getElementById("btn-publish").addEventListener("click", () => saveArticle("published", { onSaved: afterSave }));
document.getElementById("btn-preview").addEventListener("click", () => openPreview());

// ==========================================================================
// CATEGORIES
// ==========================================================================
async function renderCategories() {
  const wrap = document.getElementById("category-list");
  wrap.innerHTML = `<div class="loading-spinner" style="margin:20px auto"></div>`;
  await loadCategories();
  const withCounts = await Promise.all(categoriesCache.map(async (c) => {
    try {
      const cq = query(collection(db, "articles"), where("category", "==", c.name));
      const countSnap = await getCountFromServer(cq);
      return { ...c, count: countSnap.data().count };
    } catch { return { ...c, count: 0 }; }
  }));
  wrap.innerHTML = withCounts.map((c) => `
    <div class="category-manage-row">
      <div><strong>${escapeHtml(c.name)}</strong> <span style="color:var(--muted); font-size:0.85rem">— ${c.count} article${c.count === 1 ? "" : "s"}</span></div>
      <button class="btn btn-ghost btn-sm" data-act="del-cat" data-id="${c.id}" data-count="${c.count}">Delete</button>
    </div>`).join("") || `<p style="color:var(--muted); font-family:var(--font-ui)">No categories yet.</p>`;
}

document.getElementById("add-category-btn").addEventListener("click", async () => {
  const input = document.getElementById("new-category-name");
  const name = input.value.trim();
  if (!name) return;
  if (categoriesCache.some((c) => c.name.toLowerCase() === name.toLowerCase())) {
    toast("That category already exists", "error");
    return;
  }
  await addDoc(collection(db, "categories"), { name, slug: slugify(name), createdAt: serverTimestamp() });
  input.value = "";
  toast("Category added");
  renderCategories();
});

document.getElementById("category-list").addEventListener("click", async (e) => {
  const btn = e.target.closest("button[data-act='del-cat']");
  if (!btn) return;
  const count = Number(btn.dataset.count || 0);
  if (count > 0) {
    toast("Move or delete its articles before removing this category", "error");
    return;
  }
  const ok = await confirmDialog({ title: "Delete this category?", message: "This can't be undone." });
  if (!ok) return;
  await deleteDoc(doc(db, "categories", btn.dataset.id));
  toast("Category deleted");
  renderCategories();
});

// ==========================================================================
// SETTINGS
// ==========================================================================
document.getElementById("change-password-btn").addEventListener("click", async () => {
  const val = document.getElementById("new-password").value;
  if (val.length < 6) return toast("Password must be at least 6 characters", "error");
  try {
    await updatePassword(auth.currentUser, val);
    document.getElementById("new-password").value = "";
    toast("Password updated");
  } catch (err) {
    toast(err.code === "auth/requires-recent-login" ? "Please log out and back in, then try again" : "Couldn't update password", "error");
  }
});
